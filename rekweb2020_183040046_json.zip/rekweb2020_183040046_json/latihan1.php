<?php 

$mahasiswa = [
	[

    "nama" => "Sandikha Galih",
    "nrp" => "043040023",
    "email" => "sandikhagalih@unpas.ac.id"

	],
	[ 
	"nama" => "Erik Doank",
    "nrp" => "023040001",
    "email" => "erik@gmail.com.id"
	]

	];

$data = json_encode($mahasiswa);
echo $data;


 ?>