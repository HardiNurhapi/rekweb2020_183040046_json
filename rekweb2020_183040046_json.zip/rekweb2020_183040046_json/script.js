let mahasiswa = {
	nama : "Sandikha Galih",
    nrp : "043040023",
    email :"sandikhagalih@unpas.ac.id"

}
console.log(JSON.stringify(mahasiswa));